// const express = require('express');
// const { register, login } = require('./profle.controller');

// const router = express();
// router.post('/register', register);
// router.post('/login', login);
// // router.post('/profile', profile);

// module.exports = router;
